---
description: 'Enforce consistent spacing before and after keywords.'
---

> 🛑 This file is source code, not the primary documentation location! 🛑
>
> See **https://typescript-eslint.io/rules/keyword-spacing** for documentation.

This rule extends the base [`eslint/keyword-spacing`](https://eslint.org/docs/rules/keyword-spacing) rule.
It adds support for generic type parameters on function calls.

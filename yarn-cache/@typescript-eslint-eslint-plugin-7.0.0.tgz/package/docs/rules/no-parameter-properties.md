:::danger Deprecated

This rule has been deprecated in favour of the [`parameter-properties`](https://typescript-eslint.io/rules/parameter-properties/) rule.

:::

<!--
This doc file has been left on purpose to help direct people to the replacement rule.

Note that there is no actual way to get to this page in the normal navigation,
so end-users will only be able to get to this page from the search bar.
-->
